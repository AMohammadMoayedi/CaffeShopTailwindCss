/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./public/**/*.{html,js}"], theme: {
        extend: {
            colors: {
                "bgColors": {
                    primaryBg: "#525659",
                    topBar: "#f0f2f7",
                    bgBody: "#f3f4f6",
                },
                "textColors": {
                    primaryText: "#FFCB05", primaryTextBlue: "#38a5e9",
                }
            },
            fontFamily: {
                Dana: "Dana",
                DanaMedium: "Dana Medium",
                DanaDemiBold: "Dana DemiBold",
                Morabba: "Morabba Light",
                MorabbaMedium: "Morabba Medium",
                MorabbaBold: "Morabba Bold",
            },
            letterSpacing: {tightest: "-0.065em"},
            spacing: {
                11.5: "2.875rem",
                11.75: "2.9375rem",
                13: "3.25rem",
                17: "4.25rem",
                42: "10.5rem",
                46.5: "11.625rem",
                51.5: "12.875rem",
                67: "16.75rem",
                94.5: "23.625rem",
                150: "37.5rem",
                175: "43.75rem",
                181: "45.25rem",
                210: "52.5rem",
            },
            screens: {
                'sm': '640px', // => @media (min-width: 640px) { ... }

                'md': '768px', // => @media (min-width: 768px) { ... }

                'lg': '1024px', // => @media (min-width: 1024px) { ... }

                'xl': '1280px', // => @media (min-width: 1280px) { ... }

                '2xl': '1536px', // => @media (min-width: 1536px) { ... }
            },
            container: {
                center: true
            }
        },
    }, plugins: [function ({addVariant}) {
        addVariant("child", "& > *");
        addVariant("child-hover", "& > *:hover");
    },]
}

